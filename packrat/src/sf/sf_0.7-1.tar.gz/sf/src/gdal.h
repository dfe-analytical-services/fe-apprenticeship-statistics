void set_error_handler(void);
void unset_error_handler(void);
