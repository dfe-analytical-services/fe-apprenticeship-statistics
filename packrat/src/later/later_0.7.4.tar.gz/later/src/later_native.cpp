#include "callback_registry.h"

extern CallbackRegistry callbackRegistry;

